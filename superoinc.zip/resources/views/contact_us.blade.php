@extends("layouts.app")
@section('content')

    @include('layouts.inner-page')
    @include('layouts.contact')

    @include('layouts.order')

@endsection
