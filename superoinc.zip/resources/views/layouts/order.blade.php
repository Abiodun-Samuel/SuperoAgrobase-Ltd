<div id="order">
    <div class="container">
        <p>Are you interested in any of our products?</p> <a class="mybtn-1" href="{{ url('/Our Products') }}">Place
            order
            now</a>
    </div>
</div>
