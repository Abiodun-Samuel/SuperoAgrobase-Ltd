<section id="inner-page">
    <div class="container text-center">
        <h2> <a href="{{ url('/') }}"> Home</a> | {{ $title }} </h2>
    </div>
</section>
