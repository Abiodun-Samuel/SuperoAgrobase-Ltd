 <div class="col-lg-2 col-md-4 col-sm-6 xs">
     <div class="card m-2">
         <div class="product-box">
             <img loading="lazy" src="{{ url('/images/products/' . $product . '.jpg') }}" class="card-img-top"
                 alt="{{ $product }}">
             <div class="card-body">
                 <p class="card-text">
                     {{ $product }}
                 </p>
             </div>
         </div>

     </div>
 </div>
