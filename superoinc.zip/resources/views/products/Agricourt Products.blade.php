@extends("layouts.app")

@section('content')

    @include('layouts/inner-page')

    @include('layouts/Agricourt Products')
    @include('layouts/contact')


@endsection
