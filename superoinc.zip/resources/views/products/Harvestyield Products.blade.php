@extends("layouts.app")

@section('content')

    @include('layouts/inner-page')

    @include('layouts/Harvestyield Products')
    @include('layouts/contact')


@endsection
